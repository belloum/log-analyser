README

1. Go to the folder of the .jar
2. Run the cmd "java -jar log-analyser-0.0.1-SNAPSHOT.jar "

3. You can find some error logs in the file logs/error.logs
4. You can find some info logs in the file logs/storyboard.logs