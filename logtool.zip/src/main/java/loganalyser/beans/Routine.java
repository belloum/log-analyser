package loganalyser.beans;

public enum Routine {
	WakeUp, Meal, GoToBed
}
